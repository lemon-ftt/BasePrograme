//
//  DatabaseManage.h
//  HomeWork
//
//  Created by 范坛 on 2017/9/28.
//  Copyright © 2017年 建壮赵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDatabase.h>
#import <FMDatabaseQueue.h>

@interface DatabaseManage : NSObject

/**
 *  单例方法
 *
 *  @return 获取实例
 */
+ (id)shareInstance;

// 插入数据
- (void)insertInfoTable:(NSString *)name withAge:(NSString *)age;

// 更新数据
- (void)updateInfoTable:(NSString *)name withAge:(NSString *)age;

// 查询数据
- (NSArray *)qureyInfoTable;

// 删除表
- (void)deleteInfoTabel;

@end
