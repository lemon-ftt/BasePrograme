//
//  DatabaseManage.m
//  HomeWork
//
//  Created by 范坛 on 2017/9/28.
//  Copyright © 2017年 建壮赵. All rights reserved.
//

#import <FMDatabaseAdditions.h>
#import "DatabaseManage.h"

/**
 * 数据库地址和名字
 */
#define dataBasePath [[(NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES)) lastObject]stringByAppendingPathComponent:dataBaseName]
static NSString *dataBaseName = @"homeWorkDataBase.sqlite";

static DatabaseManage *manager = nil;//管理类实例
static FMDatabaseQueue *shareDataBaseQueue = nil;//数据库队列实例


@implementation DatabaseManage

/**
 *  单例方法
 *
 *  @return 获取实例
 */
+ (id)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[DatabaseManage alloc]init];
        shareDataBaseQueue = [FMDatabaseQueue databaseQueueWithPath:dataBasePath] ;
        [manager createTables];
    });
    return manager;
}

/**
 *  判断数据库表是否存在
 *
 *  @param tableName 表名
 *
 *  @return 返回是否存在
 */
- (BOOL)isTableExist:(NSString *)tableName {
    BOOL bl = NO;
    FMDatabase *db = [FMDatabase databaseWithPath:dataBasePath];
    if ([db open]) {
        FMResultSet *rs = [db executeQuery:@"select count(*) as 'count' from sqlite_master where type ='table' and name = ?", tableName];
        while ([rs next])
        {
            // just print out what we've got in a number of formats.
            NSInteger count = [rs intForColumn:@"count"];
            
            if (0 == count)
            {
                bl=NO;
            }
            else
            {
                bl=YES;
            }
        }
        [db close];
    }
    
    return bl;
}

/**
 *  创建数据库表
 */
- (void)createTables {
    [self createInfoTable];
}

// 创建信息表
- (void)createInfoTable {
    [shareDataBaseQueue inDatabase:^(FMDatabase * _Nonnull db) {
        if ([db open]) {
            if (![manager isTableExist:@"InfoTable"]) {
                NSString *sqlInfo = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS InfoTable ('id' INTEGER PRIMARY KEY AUTOINCREMENT, '%@' TEXT)",@"name"];
                BOOL res = [db executeUpdate:sqlInfo];
                if (!res) {
                    NSLog(@"error when creating InfoTable table");
                } else {
                    NSLog(@"success to creating InfoTable table");
                }
            }
            [db close];
        }
    }];
}

// 插入数据
- (void)insertInfoTable:(NSString *)name withAge:(NSString *)age {
    [shareDataBaseQueue inDatabase:^(FMDatabase * _Nonnull db) {
        if ([db open]) {
            // 给表增加字段
            if (![db columnExists:@"age" inTableWithName:@"InfoTable"]) {
                NSString *sql = [NSString stringWithFormat:@"ALTER TABLE %@ ADD %@ text",@"InfoTable",@"age"];
                [db executeUpdate:sql];
            }
            
            NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO InfoTable (name, age) VALUES ('%@', '%@')",name,age];
            BOOL res = [db executeUpdate:insertSql];
            if (!res) {
                NSLog(@"error when insert InfoTable table");
            } else {
                NSLog(@"success to insert InfoTable table");
            }
            
            [db close];
            
        }
    }];
}

// 更新数据
- (void)updateInfoTable:(NSString *)name withAge:(NSString *)age {
    [shareDataBaseQueue inDatabase:^(FMDatabase * _Nonnull db) {
        if ([db open]) {
            NSString *updateSql = [NSString stringWithFormat:@"UPDATE InfoTable SET name = '%@', age = '%@' WHERE (id = '%d') AND (name = '%@')",name,age,1,name];
            BOOL res = [db executeUpdate:updateSql];
            if (!res) {
                NSLog(@"error when update InfoTable table");
            } else {
                NSLog(@"success to update InfoTable table");
            }
            [db close];
        }
    }];
}

// 查询数据
- (NSArray *)qureyInfoTable {
    NSMutableArray *arr = [NSMutableArray array];
    [shareDataBaseQueue inDatabase:^(FMDatabase * _Nonnull db) {
        NSString * querySql = [NSString stringWithFormat:@"SELECT * FROM InfoTable order by id asc , age desc"];
        FMResultSet * rs = [db executeQuery:querySql];
        while ([rs next]) {
            [rs stringForColumn:@"name"];
            [arr addObject:nil];
        }
        [db close];
    }];
    return arr;
}

// 删除表
- (void)deleteInfoTabel {
    [shareDataBaseQueue inDatabase:^(FMDatabase * _Nonnull db) {
        if ([db open]) {
            NSString *deleteSql = @"DELETE FROM InfoTable";
            BOOL res = [db executeUpdate:deleteSql];
            if (!res) {
                NSLog(@"error when delete InfoTable table");
            } else {
                NSLog(@"success to delete InfoTable table");
            }
            [db close];
        }
    }];
}



@end
