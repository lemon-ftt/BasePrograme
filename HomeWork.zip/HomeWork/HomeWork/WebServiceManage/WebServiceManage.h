//
//  WebServiceManage.h
//  HomeWork
//
//  Created by 建壮赵 on 2017/9/27.
//  Copyright © 2017年 建壮赵. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    
    StatusUnknown           = -1, //未知网络
    StatusNotReachable      = 0,    //没有网络
    StatusReachableViaWWAN  = 1,    //手机自带网络
    StatusReachableViaWiFi  = 2     //wifi
    
}NetworkStatus;

typedef void( ^ ResponseSuccess)(id response);
typedef void( ^ ResponseFail)(NSError *error);

typedef void( ^ UploadProgress)(int64_t bytesProgress,
int64_t totalBytesProgress);

typedef void( ^ DownloadProgress)(int64_t bytesProgress,
int64_t totalBytesProgress);

/**
 *  方便管理请求任务。执行取消，暂停，继续等任务.
 *  - (void)cancel，取消任务
 *  - (void)suspend，暂停任务
 *  - (void)resume，继续任务
 */
typedef NSURLSessionTask URLSessionTask;

@interface WebServiceManage : NSObject

/**
 *  获取网络
 */
@property (nonatomic,assign)NetworkStatus networkStats;

/**
 单利

 @return WebServiceManage 对象
 */
+ (instancetype)sharedInstancetype;

/**
 *  开启网络监测
 */
+ (void)startMonitoring;

/**
 *  下载文件方法
 *
 *  @param url           下载地址
 *  @param saveToPath    文件保存的路径,如果不传则保存到Documents目录下，以文件本来的名字命名
 *  @param progressBlock 下载进度回调
 *  @param success       下载完成
 *  @param fail          失败
 *  @param showHUD       是否显示HUD
 *  @return 返回请求任务对象，便于操作
 */
+ (URLSessionTask *)downloadWithUrl:(NSString *)url
                           saveToPath:(NSString *)saveToPath
                             progress:(DownloadProgress )progressBlock
                              success:(ResponseSuccess )success
                              failure:(ResponseFail )fail
                              showHUD:(BOOL)showHUD;

@end
