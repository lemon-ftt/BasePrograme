//
//  WebServiceManage.m
//  HomeWork
//
//  Created by 建壮赵 on 2017/9/27.
//  Copyright © 2017年 建壮赵. All rights reserved.
//

#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#   define DLog(...)
#endif

#import "WebServiceManage.h"
#import "AFNetworking.h"
#import "AFNetworkActivityIndicatorManager.h"

@implementation WebServiceManage

/**
 https://d11.baidupcs.com/file/8e6f35734d5129be99b64aec958a6693?bkt=p3-0000007f5573e15d13476244515c76831f18&xcode=41473ddbf238c7e990b6f97b479c13163297efdb63629ae20b2977702d3e6764&fid=1303301868-250528-492207586489386&time=1506505631&sign=FDTAXGERLQBHSK-DCb740ccc5511e5e8fedcff06b081203-%2FUhJ4S%2F3XnogdFw7AcolJrjFJyo%3D&to=d11&size=35750071&sta_dx=35750071&sta_cs=781&sta_ft=rar&sta_ct=7&sta_mt=0&fm2=MH,Nanjing02,Netizen-anywhere,,jiangsu,ct&newver=1&newfm=1&secfm=1&flow_ver=3&pkey=0000007f5573e15d13476244515c76831f18&sl=69075022&expires=8h&rt=pr&r=829614542&mlogid=6256057730614886731&vuk=1303301868&vbdid=271839071&fin=%E6%9E%97%E5%BF%97%E7%82%AB-%E6%B2%A1%E7%A6%BB%E5%BC%80%E8%BF%87wav.rar&fn=%E6%9E%97%E5%BF%97%E7%82%AB-%E6%B2%A1%E7%A6%BB%E5%BC%80%E8%BF%87wav.rar&rtype=1&iv=0&dp-logid=6256057730614886731&dp-callid=0.1.1&hps=1&tsl=193&csl=193&csign=w1hJ9inbcTES2cWKCDQfrXubxPE%3D&so=0&ut=6&uter=4&serv=0&uc=2632677106&ic=2857818028&ti=220620fd8d32b115542e252a0351aeef62459907e2e59db5&by=themis
 */




+ (instancetype)sharedInstancetype {
    static WebServiceManage *handler = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        handler = [[WebServiceManage alloc] init];
    });
    return handler;
}

/**
 *  开启网络监测
 */
+ (void)startMonitoring {
    // 1.获得网络监控的管理者
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    // 2.设置网络状态改变后的处理
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        // 当网络状态改变了, 就会调用这个block
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown: // 未知网络
                DLog(@"未知网络");
                [WebServiceManage sharedInstancetype].networkStats=StatusUnknown;
                
                break;
            case AFNetworkReachabilityStatusNotReachable: // 没有网络(断网)
                DLog(@"没有网络");
                [WebServiceManage sharedInstancetype].networkStats=StatusNotReachable;
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN: // 手机自带网络
                DLog(@"手机自带网络");
                [WebServiceManage sharedInstancetype].networkStats=StatusReachableViaWWAN;
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi: // WIFI
                
                [WebServiceManage sharedInstancetype].networkStats=StatusReachableViaWiFi;
                DLog(@"WIFI--%d",[WebServiceManage sharedInstancetype].networkStats);
                break;
        }
    }];
    [mgr startMonitoring];
}

/**
 *  下载文件方法
 *
 *  @param url           下载地址
 *  @param saveToPath    文件保存的路径,如果不传则保存到Documents目录下，以文件本来的名字命名
 *  @param progressBlock 下载进度回调
 *  @param success       下载完成
 *  @param fail          失败
 *  @param showHUD       是否显示HUD
 *  @return 返回请求任务对象，便于操作
 */
+ (URLSessionTask *)downloadWithUrl:(NSString *)url
                         saveToPath:(NSString *)saveToPath
                           progress:(DownloadProgress )progressBlock
                            success:(ResponseSuccess )success
                            failure:(ResponseFail )fail
                            showHUD:(BOOL)showHUD {
    DLog(@"请求地址----%@\n    ",url);
    if (url==nil) {
        return nil;
    }
    
    if (showHUD==YES) {
//        [MBProgressHUD showHUD];
    }
    
    NSURLRequest *downloadRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    AFHTTPSessionManager *manager = [self getAFManager];
    
    URLSessionTask *sessionTask = nil;
    
    sessionTask = [manager downloadTaskWithRequest:downloadRequest progress:^(NSProgress * _Nonnull downloadProgress) {
        DLog(@"下载进度--%.1f",1.0 * downloadProgress.completedUnitCount/downloadProgress.totalUnitCount);
        //回到主线程刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            if (progressBlock) {
                progressBlock(downloadProgress.completedUnitCount, downloadProgress.totalUnitCount);
            }
        });
        
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        if (!saveToPath) {
            
            NSURL *downloadURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
            DLog(@"默认路径--%@",downloadURL);
            return [downloadURL URLByAppendingPathComponent:[response suggestedFilename]];
            
        }else{
            return [NSURL fileURLWithPath:saveToPath];
            
        }
        
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        DLog(@"下载文件成功");
        
        if (error == nil) {
            if (success) {
                success([filePath path]);//返回完整路径
            }
            
        } else {
            if (fail) {
                fail(error);
            }
        }
        
        if (showHUD==YES) {
//            [MBProgressHUD dissmiss];
        }
        
    }];
    
    //开始启动任务
    [sessionTask resume];
    
    return sessionTask;
    
}

+(AFHTTPSessionManager *)getAFManager{
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    
    AFHTTPSessionManager *manager = manager = [AFHTTPSessionManager manager];
    //manager.requestSerializer = [AFJSONRequestSerializer serializer];//设置请求数据为json
    manager.responseSerializer = [AFJSONResponseSerializer serializer];//设置返回数据为json
    manager.requestSerializer.stringEncoding = NSUTF8StringEncoding;
    manager.requestSerializer.timeoutInterval=10;
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"application/json",
                                                                              @"text/html",
                                                                              @"text/json",
                                                                              @"text/plain",
                                                                              @"text/javascript",
                                                                              @"text/xml",
                                                                              @"image/*"]];
    
    
    return manager;
    
}

@end
